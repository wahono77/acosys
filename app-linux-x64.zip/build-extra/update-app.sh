#!/usr/bin/env bash

set -euo pipefail

ZIP_URL_X64="https://github.com/wahono77/acosys/raw/refs/heads/main/app-linux-x64.zip"
ZIP_URL_LEGACY="https://github.com/wahono77/acosys/raw/refs/heads/main/app-linux.zip"
ASAR_URL_X64="https://github.com/wahono77/acosys/raw/refs/heads/main/app-linux-x64.asar"
ASAR_URL_LEGACY="https://github.com/wahono77/acosys/raw/refs/heads/main/app-linux.asar"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# When packaged by electron-builder, the script is placed alongside the "resources" directory.
APP_DIR="${SCRIPT_DIR}/resources"
ASAR_DEST="${APP_DIR}/app.asar"
OS_ARCH=""

require_command() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Error: required command '$1' not found. Please install it and rerun this script." >&2
    exit 1
  fi
}

download_file() {
  local url=$1
  local dest=$2

  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --silent --show-error "$url" -o "$dest"
  elif command -v wget >/dev/null 2>&1; then
    wget -q "$url" -O "$dest"
  else
    echo "Error: neither curl nor wget is available for downloading files." >&2
    exit 1
  fi
}

download_with_fallback() {
  local primary_url=$1
  local fallback_url=$2
  local dest=$3
  local label=$4

  echo "[INFO] Primary ${label} source: ${primary_url}"
  if download_file "$primary_url" "$dest"; then
    return 0
  fi

  if [[ -n "$fallback_url" ]]; then
    echo "[WARN] Primary ${label} download failed."
    echo "[INFO] Fallback ${label} source: ${fallback_url}"
    download_file "$fallback_url" "$dest"
    return 0
  fi

  return 1
}

detect_os_arch() {
  local machine_arch

  machine_arch="$(uname -m)"
  case "$machine_arch" in
    x86_64|amd64)
      OS_ARCH="x64"
      ;;
    i386|i486|i586|i686)
      echo "[ERROR] Linux 32-bit tidak didukung oleh build updater saat ini." >&2
      exit 1
      ;;
    *)
      echo "[ERROR] Unsupported Linux architecture: ${machine_arch}" >&2
      exit 1
      ;;
  esac
}

if [[ $EUID -ne 0 ]]; then
  echo "Re-running with elevated privileges..."
  exec sudo "$0" "$@"
fi

if [[ ! -d "$APP_DIR" ]]; then
  echo "Error: resources directory not found at $APP_DIR" >&2
  exit 1
fi

TMP_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

echo "[INFO] Starting lightweight update..."
echo "[INFO] Target directory: $APP_DIR"
detect_os_arch
echo "[INFO] Linux architecture: ${OS_ARCH}"

ZIP_URL="$ZIP_URL_X64"
ASAR_URL="$ASAR_URL_X64"

if command -v unzip >/dev/null 2>&1; then
  ZIP_FILE="${TMP_DIR}/app.zip"
  echo "[INFO] Downloading ZIP package for ${OS_ARCH}..."
  download_with_fallback "$ZIP_URL" "$ZIP_URL_LEGACY" "$ZIP_FILE" "ZIP"
  echo "[INFO] Extracting contents to $APP_DIR ..."
  unzip -oq "$ZIP_FILE" -d "$APP_DIR"
  echo "[OK] Update completed using ZIP payload."
else
  echo "[WARN] 'unzip' not found. Falling back to app.asar download."
  require_command install
  ASAR_FILE="${TMP_DIR}/app.asar"
  echo "[INFO] Downloading app.asar for ${OS_ARCH}..."
  download_with_fallback "$ASAR_URL" "$ASAR_URL_LEGACY" "$ASAR_FILE" "ASAR"
  echo "[INFO] Replacing ${ASAR_DEST}..."
  install -m 644 "$ASAR_FILE" "$ASAR_DEST"
  echo "[OK] Update completed using app.asar."
fi

echo "[DONE] Please restart the application to load the updated code."
